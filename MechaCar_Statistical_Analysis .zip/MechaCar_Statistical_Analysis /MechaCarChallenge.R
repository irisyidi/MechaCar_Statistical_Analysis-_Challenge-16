# Part 1: Linear Regression to Predict MPG
library(dplyr)
#import dataset
mechacar_data <- read.csv('MechaCar_mpg.csv') 
head(mechacar_data)
#create linear model
lm(mpg ~ vehicle_length + vehicle_weight + spoiler_angle + ground_clearance + AWD,mechacar_data) 
#summarize linear model
summary(lm(mpg ~ vehicle_length + vehicle_weight + spoiler_angle + ground_clearance + AWD,mechacar_data))

## Linear Regression to Predict MPG
# Which variables/coefficients provided a non-random amount of variance to the mpg values in the dataset?
# According to 5% significance level, vehicle_length and ground_clearance (as well as intercept) 
# are statistically unlikely to provide a non-random amount of variance. They have a significant impact on mpg. 

# Is the slope of the linear model considered to be zero? Why or why not?
# no the slope of the linear model is not zero because the p value is 5.35e-11, which is smaller than
# significant level 5% we assume. Therefore there is sufficient evidence to reject the null hypothesis, 
# which means that the slope of our linear model is not zero.

# Does this linear model predict mpg of MechaCar prototypes effectively? Why or why not?
# according to the summary output, the r-squared value is 0.71 in multiple regression model while 
# the p value remained significant. According to Pearson correlation coefficient table, mpg and the variables are positively strong 
# correlated. 

# Part 2: Create Visualizations for the Trip Analysis
# import dataset
suspension_coil_data <- read.csv('Suspension_Coil.csv') 
head(suspension_coil_data)
# create summary table
total_summary <- suspension_coil_data %>% summarize(Mean = mean(PSI), Median = median(PSI), Variance = var(PSI), SD = sd(PSI)) 
view(total_summary)

# create summary table to group each manufacturing lot 
lot_summary <- suspension_coil_data %>% group_by(Manufacturing_Lot)  %>% summarize(Mean = mean(PSI), Median = median(PSI), Variance = var(PSI), SD = sd(PSI),.groups = 'keep') 
view(lot_summary)

# Part 3: T-Tests on Suspension Coils
#compare sample versus population means
t.test(suspension_coil_data$PSI,mu=1500)
lot1_table <- subset(suspension_coil_data, Manufacturing_Lot == "Lot1")
lot2_table <- subset(suspension_coil_data, Manufacturing_Lot == "Lot2")
lot3_table <- subset(suspension_coil_data, Manufacturing_Lot == "Lot3")
t.test(lot1_table$PSI, mu=1500)
t.test(lot2_table$PSI, mu=1500)
t.test(lot3_table$PSI, mu=1500)



